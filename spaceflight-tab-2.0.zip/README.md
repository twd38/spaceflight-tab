# Spaceflight Tab - A Google Chrome extension for space enthusiasts

![Table Demo](chrome_store_files/demo.gif)

## What is Spaceflight Tab?
Spaceflight Tab is Google Chrome extension that presents a new spaceflight related image each time the user opens a new tab. Additionally, the user can access the photographer's social media profiles and can purchase the photos with a click of a button.

## Demo
[Add extension to Chrome](https://chrome.google.com/webstore/detail/spaceflight-tab/ljpohllnndbgdcmnphalclhkckdigfdm?hl=en)